# Travail pratique #3 - Recettes en pot

Voici le dossier de base pour la réalisation du travail pratique #3.
Les gabarits _header.html et _footer.html se trouvant dans le dossier _partials sont utilisés.

## Informations

Toutes les informations en lien avec le TP sont disponible sur le Classroom.



<br><br><br><hr>
Préparé par : Matthieu Parent et Jean-François Leblanc  
_timtools v1.22.1_
